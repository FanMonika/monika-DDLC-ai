; ============================================================
; Monika AI — Inno Setup инсталяционный скрипт
; Собирает один файл setup.exe: Monika.exe + все ресурсы.
;
; ВАЖНО: скрипт лежит в папке installer\, поэтому пути к
; файлам проекта указаны относительно неё (..\).
; Компиляция:  ISCC.exe Monika.iss
; Результат:   installer\release\Monika_Setup.exe
; ============================================================

#define MyAppName "Monika AI"
#define MyAppVersion "1.0"
#define MyAppPublisher "Monika AI"
#define MyAppExeName "Monika.exe"

[Setup]
AppId={{A1B2C3D4-E5F6-7890-ABCD-EF1234567890}
AppName={#MyAppName}
AppVersion={#MyAppVersion}
AppPublisher={#MyAppPublisher}
DefaultDirName={autopf}\{#MyAppName}
DefaultGroupName={#MyAppName}
AllowNoIcons=yes
LicenseFile=..\LICENSE
InfoBeforeFile=..\КАК УСТАНОВИТЬ.txt
OutputDir=release
OutputBaseFilename=Monika_Setup
Compression=lzma
SolidCompression=yes
PrivilegesRequired=none
PrivilegesRequiredOverridesAllowed=none
DisableProgramGroupPage=yes

[Languages]
Name: "russian"; MessagesFile: "compiler:Languages\Russian.isl"
Name: "english"; MessagesFile: "compiler:Default.isl"

[Tasks]
Name: "desktopicon"; Description: "{cm:CreateDesktopIcon}"; GroupDescription: "{cm:AdditionalIcons}"; Flags: unchecked

[Dirs]
Name: "{app}\sprites"
Name: "{app}\music"
Name: "{app}\monika_files"

[Files]
Source: "..\dist\{#MyAppExeName}"; DestDir: "{app}"; Flags: ignoreversion
Source: "..\sprites\*"; DestDir: "{app}\sprites"; Flags: ignoreversion recursesubdirs createallsubdirs
Source: "..\music\*"; DestDir: "{app}\music"; Flags: ignoreversion recursesubdirs createallsubdirs
Source: "..\monika_files\*"; DestDir: "{app}\monika_files"; Flags: ignoreversion recursesubdirs createallsubdirs

[Icons]
Name: "{group}\{#MyAppName}"; Filename: "{app}\{#MyAppExeName}"
Name: "{autodesktop}\{#MyAppName}"; Filename: "{app}\{#MyAppExeName}"; Tasks: desktopicon

[Run]
Filename: "{app}\{#MyAppExeName}"; Description: "{cm:LaunchProgram,{#StringChange(MyAppName, '&', '&&')}}"; Flags: nowait postinstall skipifsilent

[UninstallDelete]
Type: dirifempty; Name: "{app}\sprites"
Type: dirifempty; Name: "{app}\music"
Type: dirifempty; Name: "{app}\monika_files"
