@echo off
setlocal enabledelayedexpansion
cd /d "%~dp0"
title Monika — Setup
chcp 65001 >nul 2>&1

set LOG=%~dp0install_log.txt
echo ============================================= > "%LOG%"
echo Monika install log — %DATE% %TIME%          >> "%LOG%"
echo ============================================= >> "%LOG%"

:: ══════════════════════════════════════════════════════════════════
::   Цвета (работают в Windows 10/11)
:: ══════════════════════════════════════════════════════════════════
for /f %%a in ('echo prompt $E ^| cmd') do set "ESC=%%a"
set "PINK=%ESC%[95m"
set "GREEN=%ESC%[92m"
set "RED=%ESC%[91m"
set "YELLOW=%ESC%[93m"
set "CYAN=%ESC%[96m"
set "RESET=%ESC%[0m"
set "BOLD=%ESC%[1m"

cls
echo.
echo %PINK%%BOLD%  ╔══════════════════════════════════════════════════════════╗%RESET%
echo %PINK%%BOLD%  ║                                                          ║%RESET%
echo %PINK%%BOLD%  ║          M O N I K A  —  A I  A S S I S T A N T        ║%RESET%
echo %PINK%%BOLD%  ║                      Setup v2.0                          ║%RESET%
echo %PINK%%BOLD%  ║                                                          ║%RESET%
echo %PINK%%BOLD%  ╚══════════════════════════════════════════════════════════╝%RESET%
echo.
echo  %CYAN%Автоматическая установка: Python + библиотеки + сборка EXE%RESET%
echo  %CYAN%Занимает около 3-7 минут. Просто подожди.%RESET%
echo.

:: ══════════════════════════════════════════════════════════════════
::   0. Проверка файлов проекта
:: ══════════════════════════════════════════════════════════════════
echo  %YELLOW%[0/4]%RESET% Проверка файлов проекта...

if not exist "%~dp0monika.py" (
    echo.
    echo  %RED%[X] Файл monika.py не найден рядом с install.bat%RESET%
    echo      Убедись что ты распаковал ВЕСЬ архив целиком,
    echo      а не только install.bat.
    echo.
    pause & exit /b 1
)
if not exist "%~dp0requirements.txt" (
    echo.
    echo  %RED%[X] Файл requirements.txt не найден рядом с install.bat%RESET%
    echo      Убедись что ты распаковал ВЕСЬ архив целиком.
    echo.
    pause & exit /b 1
)
echo  %GREEN%[OK]%RESET% Файлы проекта найдены.
echo.

:: ══════════════════════════════════════════════════════════════════
::   1. Поиск / установка Python
:: ══════════════════════════════════════════════════════════════════
echo  %YELLOW%[1/4]%RESET% Поиск Python...

set PY=
where py     >nul 2>nul && set PY=py
if "%PY%"=="" where python >nul 2>nul && set PY=python

if "%PY%"=="" (
    echo.
    echo  %YELLOW%[!]%RESET% Python не найден. Пробую установить автоматически...
    echo      ^(потребуется интернет и пару минут^)
    echo.
    winget install -e --id Python.Python.3.12 --silent ^
        --accept-package-agreements --accept-source-agreements >> "%LOG%" 2>&1

    :: обновляем PATH без перезапуска
    for /f "tokens=*" %%i in ('powershell -NoProfile -Command ^
        "[System.Environment]::GetEnvironmentVariable(\"PATH\",\"Machine\")"') do set "SYSPATH=%%i"
    set "PATH=%SYSPATH%;%PATH%"

    timeout /t 5 >nul
    where py     >nul 2>nul && set PY=py
    if "%PY%"=="" where python >nul 2>nul && set PY=python
)

if "%PY%"=="" (
    echo.
    echo  %RED%[X] Не удалось установить Python автоматически.%RESET%
    echo.
    echo  Установи вручную ^(2 минуты^):
    echo    1. Открой https://www.python.org/downloads/
    echo    2. Скачай и запусти установщик
    echo    3. Обязательно отметь: %BOLD%"Add Python to PATH"%RESET%
    echo    4. Снова запусти install.bat
    echo.
    pause & exit /b 1
)

:: Показываем версию Python
for /f "tokens=*" %%v in ('%PY% --version 2^>^&1') do set PYVER=%%v
echo  %GREEN%[OK]%RESET% %PYVER% найден.
echo.

:: ══════════════════════════════════════════════════════════════════
::   2. Установка библиотек
:: ══════════════════════════════════════════════════════════════════
echo  %YELLOW%[2/4]%RESET% Установка библиотек...
echo       Это займёт 3-5 минут. Не закрывай окно!
echo.

:: Обновляем pip
%PY% -m pip install --upgrade pip --quiet >> "%LOG%" 2>&1

:: Убираем старый pygame (конфликтует с pygame-ce)
%PY% -m pip uninstall pygame -y >> "%LOG%" 2>&1

:: Устанавливаем основные зависимости из requirements.txt
echo       Шаг 1/3: основные библиотеки...
%PY% -m pip install -r requirements.txt --prefer-binary --quiet >> "%LOG%" 2>&1
if errorlevel 1 (
    echo.
    echo  %RED%[X] Ошибка установки основных библиотек.%RESET%
    echo      Проверь интернет и запусти install.bat снова.
    echo      Подробности: install_log.txt
    echo.
    pause & exit /b 1
)

:: Устанавливаем edge-tts (TTS от Microsoft, бесплатный)
echo       Шаг 2/3: edge-tts ^(голос Моники^)...
%PY% -m pip install edge-tts --quiet >> "%LOG%" 2>&1
if errorlevel 1 (
    echo  %YELLOW%[!]%RESET% edge-tts не установился. Голос будет отключён.
    echo      ^(всё остальное работает нормально^)
    echo      Попробуй вручную: pip install edge-tts
) else (
    echo  %GREEN%[OK]%RESET% edge-tts установлен.
)

:: Устанавливаем pyvts (управление VTube Studio из Python)
echo       Шаг 3/3: pyvts ^(lip sync с VTube Studio^)...
%PY% -m pip install pyvts --quiet >> "%LOG%" 2>&1
if errorlevel 1 (
    echo  %YELLOW%[!]%RESET% pyvts не установился. Lip sync через VTube Studio будет отключён.
    echo      Попробуй вручную: pip install pyvts
) else (
    echo  %GREEN%[OK]%RESET% pyvts установлен.
)

:: Устанавливаем PyInstaller для сборки EXE
%PY% -m pip install pyinstaller --quiet >> "%LOG%" 2>&1

echo.
echo  %GREEN%[OK]%RESET% Все библиотеки установлены.
echo.

:: ══════════════════════════════════════════════════════════════════
::   3. Сборка Monika.exe
:: ══════════════════════════════════════════════════════════════════
echo  %YELLOW%[3/4]%RESET% Сборка Monika.exe...
echo       Обычно 1-3 минуты. Окно может мигать — это нормально.
echo.

%PY% -m PyInstaller --noconfirm --onefile --windowed --noupx ^
    --name Monika ^
    --hidden-import pystray._win32 ^
    --hidden-import edge_tts ^
    --hidden-import edge_tts.communicate ^
    --hidden-import pyvts ^
    --hidden-import asyncio ^
    --hidden-import aiohttp ^
    --hidden-import aiofiles ^
    --collect-submodules pystray ^
    --collect-submodules edge_tts ^
    --collect-all cv2 ^
    monika.py >> "%LOG%" 2>&1

if errorlevel 1 (
    echo.
    echo  %RED%[X] Сборка завершилась с ошибкой.%RESET%
    echo      Попробуй запустить install.bat от имени Администратора.
    echo      Подробности: install_log.txt
    echo.
    pause & exit /b 1
)

copy /y "dist\Monika.exe" "Monika.exe" >nul 2>&1
rmdir /s /q dist  >nul 2>&1
rmdir /s /q build >nul 2>&1
del /q Monika.spec >nul 2>&1

if not exist "Monika.exe" (
    echo.
    echo  %RED%[X] Monika.exe не был создан.%RESET%
    echo      Подробности: install_log.txt
    echo.
    pause & exit /b 1
)
echo  %GREEN%[OK]%RESET% Monika.exe готов.
echo.

:: ══════════════════════════════════════════════════════════════════
::   4. Ярлык на рабочем столе
:: ══════════════════════════════════════════════════════════════════
echo  %YELLOW%[4/4]%RESET% Создание ярлыка на рабочем столе...

for /f "usebackq tokens=*" %%i in (`powershell -NoProfile -Command ^
    "[Environment]::GetFolderPath('Desktop')"`) do set DESKTOP=%%i

if exist "%DESKTOP%" (
    echo Set oWS = WScript.CreateObject("WScript.Shell")  > "%TEMP%\mk_monika.vbs"
    echo sLinkFile = "%DESKTOP%\Monika.lnk"              >> "%TEMP%\mk_monika.vbs"
    echo Set oLink = oWS.CreateShortcut(sLinkFile)       >> "%TEMP%\mk_monika.vbs"
    echo oLink.TargetPath = "%CD%\Monika.exe"            >> "%TEMP%\mk_monika.vbs"
    echo oLink.WorkingDirectory = "%CD%"                 >> "%TEMP%\mk_monika.vbs"
    echo oLink.Description = "Monika AI Assistant"       >> "%TEMP%\mk_monika.vbs"
    echo oLink.Save                                      >> "%TEMP%\mk_monika.vbs"
    cscript //nologo "%TEMP%\mk_monika.vbs" >nul 2>&1
    del /q "%TEMP%\mk_monika.vbs" >nul 2>&1
    echo  %GREEN%[OK]%RESET% Ярлык создан на рабочем столе.
) else (
    echo  %YELLOW%[!]%RESET% Рабочий стол не найден, ярлык пропущен.
)
echo.

:: ══════════════════════════════════════════════════════════════════
::   5. Готово!
:: ══════════════════════════════════════════════════════════════════
echo.
echo %GREEN%%BOLD%  ╔══════════════════════════════════════════════════════════╗%RESET%
echo %GREEN%%BOLD%  ║                                                          ║%RESET%
echo %GREEN%%BOLD%  ║               УСТАНОВКА ЗАВЕРШЕНА!  ✓                   ║%RESET%
echo %GREEN%%BOLD%  ║                                                          ║%RESET%
echo %GREEN%%BOLD%  ╚══════════════════════════════════════════════════════════╝%RESET%
echo.
echo  Дальше запускай только %BOLD%Monika.exe%RESET% ^(или ярлык на рабочем столе^).
echo  install.bat больше не нужен.
echo.
echo  %PINK%%BOLD%  ВАЖНО — первый запуск:%RESET%
echo.
echo   1. Вставь API ключ во вкладке %BOLD%"Ключи"%RESET%
echo      Бесплатный ключ: %CYAN%openrouter.ai%RESET%
echo.
echo   2. Для lip sync через VTube Studio:
echo      — Запусти VTube Studio
echo      — Настройки → API → включи %BOLD%"Start API"%RESET% ^(порт 8001^)
echo      — Перезапусти Monika.exe
echo.
echo   3. Спрайты Моники клади в папку %BOLD%sprites\%RESET%
echo      Имена файлов = эмоции: neutral.png, happy.png, sad.png...
echo.
echo   4. Для скримера положи %BOLD%screamer.mp4%RESET% в папку sprites\
echo.
echo %PINK%%BOLD%  ══════════════════════════════════════════════════════════%RESET%
echo.

start "" "Monika.exe"
timeout /t 2 >nul
exit /b 0
