@echo off
chcp 65001 >nul
cd /d "%~dp0"
title Monika

set PY=
where py >nul 2>nul && set PY=py -3
if "%PY%"=="" where python >nul 2>nul && set PY=python
if "%PY%"=="" goto nopython

%PY% -c "import mss, pygame, pystray, requests, PIL" >nul 2>nul
if errorlevel 1 goto install
goto run

:install
echo Первый запуск: ставлю нужные библиотеки, это займёт минуту...
%PY% -m pip install --upgrade pip
%PY% -m pip install -r requirements.txt
if errorlevel 1 goto pipfail

:run
%PY% monika.py
if errorlevel 1 pause
exit /b 0

:nopython
echo Python не найден.
echo Скачай его с https://www.python.org/downloads/ и при установке поставь галочку "Add python.exe to PATH".
pause
exit /b 1

:pipfail
echo Не удалось установить библиотеки. Проверь интернет и запусти файл ещё раз.
pause
exit /b 1