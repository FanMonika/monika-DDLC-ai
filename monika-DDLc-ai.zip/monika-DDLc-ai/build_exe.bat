@echo off
chcp 65001 >nul
cd /d "%~dp0"
title Сборка Monika.exe

set PY=
where py >nul 2>nul && set PY=py -3
if "%PY%"=="" where python >nul 2>nul && set PY=python
if "%PY%"=="" (
  echo Python не найден. Установи его с https://www.python.org/downloads/
  pause
  exit /b 1
)

%PY% -m pip install --upgrade pip
%PY% -m pip install -r requirements.txt pyinstaller
if errorlevel 1 (
  echo Не удалось установить библиотеки.
  pause
  exit /b 1
)

%PY% -m PyInstaller --noconfirm --onefile --windowed --noupx --name Monika --hidden-import pystray._win32 --collect-submodules pystray monika.py
if errorlevel 1 (
  echo Сборка не удалась.
  pause
  exit /b 1
)

echo.
echo Готово: dist\Monika.exe
pause